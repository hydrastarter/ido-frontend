export const DASHBOARD_URL = "/";
export const ADMIN_URL = "/admin";
export const CROWDSALE_DETAILS_URL = "/details/:id";
