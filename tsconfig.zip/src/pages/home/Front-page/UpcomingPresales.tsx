
// import React, { useState, useRef  } from 'react'

// import slide1 from '../../assets/images/banner-slider.png';
// import slide2 from '../../assets/images/logo-sl.svg';
// import prev from '../../assets/images/icons/prev.svg';
// import next from '../../assets/images/icons/next.svg';

// import middlebg from '../../assets/images/bg-middle.png';


// import Slider from "react-slick";
// function UpcomingPresales() {

//     const customeSlider = useRef();
    
//     const [sliderSettings, setSliderSettings] = useState({
//         infinite: true,
//         speed: 1500,
//         arrows: false,
//         slidesToShow: 4,
//         autoplay: false,
//         margin:15,
//         dots:false,
//         autoplaySpeed: 1000,
//         slidesToScroll: 1,
//         responsive: [
//           {
//             breakpoint: 992,
//             settings: {
//               slidesToShow: 3,
//               slidesToScroll: 3,
//               adaptiveHeight: true,
//             },
//           },
//           {
//             breakpoint: 600,
//             settings: {
//               slidesToShow: 1,
//               slidesToScroll: 1,
//             },
//           },
//         ],
//     });

//     const gotoNext = () => {
//         customeSlider.current.slickNext()
//       }
    
//       const gotoPrev = () => {
//         customeSlider.current.slickPrev()
//       }

//     return (
//         <>
          

//           <div className='presales-section'>
//             <div className='container'>
//                     <div className="heading-main">
//                         <h2>Upcoming Presales</h2>
//                     </div>
//                     <div className='slider-mn'>
//                         <Slider {...sliderSettings} ref={customeSlider} className="Journeynumber">
//                         <div className="Journey-item">
//                             <div className="journey-des-top">
//                                 <img src={slide1} className='' alt=''/>
//                                 <span className="number">
//                                     Start Date & Time
//                                 </span>
//                             </div>
//                             <div className="journey-des-btm">
//                                 <div className='logo-cont'>
//                                     <img src={slide2} />
//                                 </div>
//                                 <div className='headings'>
//                                     <h2>Citizen Conflict</h2>
//                                     <h4>$CCCASH</h4>
//                                     <h5 className='h4'>Real you is not enough</h5>
//                                 </div>
//                                 <div className='goals-se'>
//                                     <div className='goals-box'>
//                                         <h5>Fundraiser Goal</h5>
//                                         <h2>$650,000</h2>
//                                     </div>
//                                     <div className='goals-box'>
//                                         <h5>Fundraiser Goal</h5>
//                                         <h2>$500</h2>
//                                     </div>
//                                 </div>
//                                 <div className='link-btm'>
//                                     <a href='#'>Token Sale</a>
//                                 </div>
                                
//                             </div>
//                         </div>
//                         <div className="Journey-item">
//                             <div className="journey-des-top">
//                                 <img src={slide1} className='' alt=''/>
//                                 <span className="number">
//                                     Start Date & Time
//                                 </span>
//                             </div>
//                             <div className="journey-des-btm">
//                                 <div className='logo-cont'>
//                                     <img src={slide2} />
//                                 </div>
//                                 <div className='headings'>
//                                     <h2>Citizen Conflict</h2>
//                                     <h4>$CCCASH</h4>
//                                     <h5 className='h4'>Real you is not enough</h5>
//                                 </div>
//                                 <div className='goals-se'>
//                                     <div className='goals-box'>
//                                         <h5>Fundraiser Goal</h5>
//                                         <h2>$650,000</h2>
//                                     </div>
//                                     <div className='goals-box'>
//                                         <h5>Fundraiser Goal</h5>
//                                         <h2>$500</h2>
//                                     </div>
//                                 </div>
//                                 <div className='link-btm'>
//                                     <a href='#'>Token Sale</a>
//                                 </div>
//                             </div>
//                         </div>
//                         <div className="Journey-item">
//                             <div className="journey-des-top">
//                                 <img src={slide1} className='' alt=''/>
//                                 <span className="number">
//                                     Start Date & Time
//                                 </span>
//                             </div>
//                             <div className="journey-des-btm">
//                                 <div className='logo-cont'>
//                                     <img src={slide2} />
//                                 </div>
//                                 <div className='headings'>
//                                     <h2>Citizen Conflict</h2>
//                                     <h4>$CCCASH</h4>
//                                     <h5 className='h4'>Real you is not enough</h5>
//                                 </div>
//                                 <div className='goals-se'>
//                                     <div className='goals-box'>
//                                         <h5>Fundraiser Goal</h5>
//                                         <h2>$650,000</h2>
//                                     </div>
//                                     <div className='goals-box'>
//                                         <h5>Fundraiser Goal</h5>
//                                         <h2>$500</h2>
//                                     </div>
//                                 </div>
//                                 <div className='link-btm'>
//                                     <a href='#'>Token Sale</a>
//                                 </div>
//                             </div>
//                         </div>
//                         <div className="Journey-item">
//                             <div className="journey-des-top">
//                                 <img src={slide1} className='' alt=''/>
//                                 <span className="number">
//                                     Start Date & Time
//                                 </span>
//                             </div>
//                             <div className="journey-des-btm">
//                                 <div className='logo-cont'>
//                                     <img src={slide2} />
//                                 </div>
//                                 <div className='headings'>
//                                     <h2>Citizen Conflict</h2>
//                                     <h4>$CCCASH</h4>
//                                     <h5 className='h4'>Real you is not enough</h5>
//                                 </div>
//                                 <div className='goals-se'>
//                                     <div className='goals-box'>
//                                         <h5>Fundraiser Goal</h5>
//                                         <h2>$650,000</h2>
//                                     </div>
//                                     <div className='goals-box'>
//                                         <h5>Fundraiser Goal</h5>
//                                         <h2>$500</h2>
//                                     </div>
//                                 </div>
//                                 <div className='link-btm'>
//                                     <a href='#'>Token Sale</a>
//                                 </div>
//                             </div>
//                         </div>
//                         <div className="Journey-item">
//                             <div className="journey-des-top">
//                                 <img src={slide1} className='' alt=''/>
//                                 <span className="number">
//                                     Start Date & Time
//                                 </span>
//                             </div>
//                             <div className="journey-des-btm">
//                                 <div className='logo-cont'>
//                                     <img src={slide2} />
//                                 </div>
//                                 <div className='headings'>
//                                     <h2>Citizen Conflict</h2>
//                                     <h4>$CCCASH</h4>
//                                     <h5 className='h4'>Real you is not enough</h5>
//                                 </div>
//                                 <div className='goals-se'>
//                                     <div className='goals-box'>
//                                         <h5>Fundraiser Goal</h5>
//                                         <h2>$650,000</h2>
//                                     </div>
//                                     <div className='goals-box'>
//                                         <h5>Fundraiser Goal</h5>
//                                         <h2>$500</h2>
//                                     </div>
//                                 </div>
//                                 <div className='link-btm'>
//                                     <a href='#'>Token Sale</a>
//                                 </div>
//                             </div>
//                         </div>
//                         </Slider>
//                         <div className='nav-slider'>
//                             <span onClick={()=>gotoNext()}><img src={next} className='' alt=''/></span>
//                             <span onClick={()=>gotoPrev()}><img src={prev} className='' alt=''/></span>
//                         </div>
//                     </div>
//                     <div className='link-btn'>
//                         <a href='#' className='btn-link'>View All</a>
//                     </div>
                    
//             </div>
//             <div className=''>
//                     <img src={middlebg} className='vect1-middle' />
//                 </div>
//         </div>

       
//         </>
//         )
//     }
    
// export default UpcomingPresales;
    